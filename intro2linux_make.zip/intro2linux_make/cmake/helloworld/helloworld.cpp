// my first program in C++
#include <iostream>

int main()
{
  std::cout << "Hello World!\n";
}
