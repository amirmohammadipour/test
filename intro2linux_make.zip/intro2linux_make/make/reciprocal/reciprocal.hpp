#ifdef __cplusplus
extern "C" {
#endif
extern double reciprocal (int c);
#ifdef __cplusplus
}
#endif
